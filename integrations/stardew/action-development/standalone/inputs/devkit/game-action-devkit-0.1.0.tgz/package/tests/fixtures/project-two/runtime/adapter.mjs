import { createGameRuntimePlugin } from "@gamebuddy/game-action-devkit";

const ACTION_IDS = Object.freeze(["rotate_dial", "archive_note"]);
const ACTION_ID_SET = new Set(ACTION_IDS);
const STATUS_BY_COMMAND = Object.freeze({
  check: "check_passed",
  preflight: "preflight_ready",
  status: "status_ready",
});

const FIXTURE_RUNTIME = createGameRuntimePlugin({
  gameId: "papertrail_fixture",
  targets: [{
    targetId: "papertrail_target",
    targetVersion: "v1",
    actions: ACTION_IDS.map((actionId) => ({
      actionId,
      verifier: { admit: () => true, verify: () => true },
    })),
  }],
});

function requireAction(actionId) {
  if (typeof actionId !== "string" || !ACTION_ID_SET.has(actionId)) {
    throw new Error("papertrail_fixture_action_not_available");
  }
}

export async function runActionProject({ manifest, invocation }) {
  requireAction(invocation.actionId);
  if (invocation.command === "run-live") {
    const admission = FIXTURE_RUNTIME.inspectTarget({
      targetId: "papertrail_target",
      targetVersion: "v1",
      actionId: invocation.actionId,
      runId: invocation.runId,
    });
    if (admission.blocked) throw new Error("papertrail_fixture_admission_unexpectedly_blocked");
    const outcome = FIXTURE_RUNTIME.run({
      admission: admission.admission,
      actionRunner: {
        actionId: invocation.actionId,
        runId: invocation.runId,
        execute: () => ({
          receipt: { state: "blocked", code: "non_production_fixture", evidence: null },
          postcondition: { state: "not_applicable", code: null, evidence: null },
          cleanup: { state: "complete", code: "complete" },
        }),
      },
    });
    return {
      schema: "gamebuddy-action-scenario-result/v1",
      gameId: manifest.gameId,
      status: "blocked",
      outcome: "blocked",
      reasonCode: outcome.receipt?.code ?? "non_production_fixture",
      claimScope: "fixture_only",
      actionId: invocation.actionId,
      runId: invocation.runId,
    };
  }

  return {
    schema: "gamebuddy-action-scenario-result/v1",
    gameId: manifest.gameId,
    status: STATUS_BY_COMMAND[invocation.command],
    claimScope: "fixture_only",
    actionId: invocation.actionId,
    briefFile: invocation.briefFile ?? null,
  };
}
